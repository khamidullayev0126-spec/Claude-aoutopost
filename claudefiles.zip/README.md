# Claude maslahatlar — avtomatik post pipeline'i

"Dasturchi kundaligi" Telegram kanaliga har kuni soat 17:00 da AI-tayyorlagan
post (matn + rasm, haftada bir marta + audio) avtomatik chiqaradigan, admin
tasdig'iga muhtoj bo'lgan worker.

## Qanday ishlaydi

1. Har kuni 16:50 da (17:00 - 10 daqiqa) bot mavzu topadi, post matnini,
   rasmini (har 3-postda matn-only, rasmsiz) va kerak bo'lsa (haftada 1
   marta) audiosini generatsiya qiladi, o'z-o'zini sifat nazoratidan
   o'tkazadi.
2. Tayyor postni sizga (ADMIN_CHAT_ID) "🔁 Qayta qilish" tugmasi bilan
   yuboradi.
3. Agar hech narsa bosmasangiz — 17:00 da post avtomatik kanalga chiqadi.
4. Agar "Qayta qilish"ni bossangiz — post qayta generatsiya qilinadi va
   tayyor bo'lishi bilan (17:00 o'tib ketgan bo'lsa ham) darhol kanalga
   chiqariladi.

## 1-qadam: ADMIN_CHAT_ID'ni topish

1. Botni BotFather orqali allaqachon yaratgansiz (token bor).
2. Telegram'da botga `/start` deb yozing.
3. Brauzerda oching:
   `https://api.telegram.org/bot<TOKEN>/getUpdates`
4. Javobdagi `"chat":{"id": ...}` qiymatini oling — shu sizning
   `ADMIN_CHAT_ID`'ingiz.
   (Deploy qilgandan keyin ham botga istalgan vaqt `/myid` deb yozib shu
   qiymatni olishingiz mumkin.)

## 2-qadam: Botni kanalga admin qilib qo'shish

Botni `@AbdulhamidDasturchi_kundaligi` kanaliga **admin** sifatida qo'shing
("Post joylashtirish" huquqi bilan) — aks holda u kanalga yoza olmaydi.

## 3-qadam: Render'da joylashtirish

1. Ushbu papkani GitHub repo'ga yuklang (yoki Render CLI orqali to'g'ridan-to'g'ri deploy qiling).
2. Render Dashboard → **New → Blueprint** → repo'ni tanlang → `render.yaml`
   avtomatik topiladi.
3. Deploy paytida quyidagi **environment variable**'larni kiritish so'raladi
   (`sync: false` bo'lganlar — maxfiy qiymatlar, Dashboard'da qo'lda kiritiladi):
   - `TELEGRAM_BOT_TOKEN`
   - `GEMINI_API_KEY`
   - `ELEVENLABS_API_KEY`
   - `ADMIN_CHAT_ID`
4. Deploy tugagach, service turi **Background Worker** bo'lgani uchun ochiq
   URL bo'lmaydi — bu normal, u fonda ishlab turadi.

## Ixtiyoriy sozlamalar (render.yaml yoki Dashboard'da o'zgartiriladi)

| O'zgaruvchi | Ma'no | Default |
|---|---|---|
| `PUBLISH_HOUR` / `PUBLISH_MINUTE` | Nashr vaqti | 17:00 |
| `PREVIEW_MINUTES_BEFORE` | Necha daqiqa oldin preview yuborilsin | 10 |
| `ELEVENLABS_VOICE_ID` | ElevenLabs ovoz ID | default ovoz |
| `RUBRIC_TOPIC_PROMPT` | Rubrika mavzusi tavsifi | AI va dasturlash yangiliklari/faktlari |

## Muhim eslatishlar

- **Xavfsizlik:** siz token/kalitlarni suhbatda ochiq yubordingiz — deploy
  qilishdan oldin BotFather'da (`/revoke`), Google AI Studio'da va
  ElevenLabs profilida ularni **yangilab (regenerate)** qo'ying, keyin
  yangi qiymatlarni Render'ga kiriting.
- **Holat saqlash:** hisoblagichlar (`har 3-post`, `haftalik audio`) oddiy
  faylda saqlanadi. Worker qayta ishga tushganda (redeploy) preview
  kutish holati yo'qoladi — bu kamdan-kam holat, lekin agar bu muhim
  bo'lsa, keyinchalik Render Persistent Disk yoki Postgres bilan
  mustahkamlash mumkin.
- **Sinov:** birinchi marta ishga tushirishdan oldin `PUBLISH_HOUR`/`PUBLISH_MINUTE`'ni
  bir necha daqiqa keyingi vaqtga qo'yib sinab ko'rishni tavsiya qilaman.
