"""
Oddiy JSON-fayl asosidagi holat saqlash.
Saqlanadigan narsalar:
  - post_count: nechta post chiqqani (har 3-postdan 1 tasi matn-only bo'lishi uchun)
  - last_audio_iso_week: audio oxirgi marta qaysi ISO-hafta uchun yuborilgani
"""
import json
import os
import threading
from config import STATE_FILE

_lock = threading.Lock()

_DEFAULT_STATE = {
    "post_count": 0,
    "last_audio_iso_week": None,  # masalan "2026-W40"
}


def _read() -> dict:
    if not os.path.exists(STATE_FILE):
        return dict(_DEFAULT_STATE)
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        merged = dict(_DEFAULT_STATE)
        merged.update(data)
        return merged
    except (json.JSONDecodeError, OSError):
        return dict(_DEFAULT_STATE)


def _write(data: dict) -> None:
    os.makedirs(os.path.dirname(STATE_FILE) or ".", exist_ok=True)
    tmp_path = STATE_FILE + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, STATE_FILE)


def get_state() -> dict:
    with _lock:
        return _read()


def increment_post_count() -> int:
    """Post chiqarilgandan keyin chaqiriladi. Yangi post_count qiymatini qaytaradi."""
    with _lock:
        data = _read()
        data["post_count"] = data.get("post_count", 0) + 1
        _write(data)
        return data["post_count"]


def should_be_text_only(next_post_number: int) -> bool:
    """Har 3-postdan 1 tasi (3, 6, 9, ...) faqat matn bo'ladi."""
    return next_post_number % 3 == 0


def should_send_audio_this_week(iso_week: str) -> bool:
    data = get_state()
    return data.get("last_audio_iso_week") != iso_week


def mark_audio_sent(iso_week: str) -> None:
    with _lock:
        data = _read()
        data["last_audio_iso_week"] = iso_week
        _write(data)
