"""
"Claude maslahatlar" avtomatik post pipeline'i — asosiy worker.

Ishlash tartibi:
  1. Har kuni (PUBLISH_HOUR:PUBLISH_MINUTE - PREVIEW_MINUTES_BEFORE) da
     kontent tayyorlanadi va ADMIN_CHAT_ID'ga "Qayta qilish" tugmasi bilan
     preview yuboriladi.
  2. Agar admin PREVIEW_MINUTES_BEFORE daqiqa ichida tugmani bossa —
     kontent qaytadan generatsiya qilinadi va tayyor bo'lishi bilan (nashr
     vaqti o'tib ketgan bo'lsa ham) darhol kanalga chiqariladi.
  3. Agar hech narsa bosilmasa — PUBLISH_HOUR:PUBLISH_MINUTE'da asl post
     avtomatik kanalga chiqadi.

Ishga tushirish: python bot.py   (Render'da "Background Worker" sifatida)
"""
import html
import logging
import re
import uuid
from datetime import datetime, time as dt_time, timedelta
from io import BytesIO

import pytz
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

import state
from config import (
    ADMIN_CHAT_ID,
    CHANNEL_ID,
    PREVIEW_MINUTES_BEFORE,
    PUBLISH_HOUR,
    PUBLISH_MINUTE,
    TELEGRAM_BOT_TOKEN,
    TIMEZONE,
)
from content_gen import generate_post
from image_gen import generate_image
from audio_gen import generate_audio
from qc import check_post

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO
)
log = logging.getLogger("autopost")

TZ = pytz.timezone(TIMEZONE)

# Kun davomidagi kutilayotgan postlar: {post_id: {...}}
# Eslatma: bu xotirada saqlanadi — worker qayta ishga tushsa (redeploy)
# kutilayotgan preview holati yo'qoladi. Bitta postga 10 daqiqalik oyna
# uchun bu amaliy jihatdan yetarli.
PENDING: dict[str, dict] = {}

MAX_GENERATION_ATTEMPTS = 3


def _strip_html(text: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", text))


def _build_content_package(text_only: bool, want_audio: bool) -> dict:
    """Matn (+QC) va kerak bo'lsa rasm/audio bilan to'liq post paketini tayyorlaydi."""
    last_reason = ""
    for attempt in range(1, MAX_GENERATION_ATTEMPTS + 1):
        post = generate_post()
        plain = _strip_html(post["post_html"])
        passed, reason = check_post(plain)
        if passed:
            break
        last_reason = reason
        log.warning("QC rad etdi (urinish %s/%s): %s", attempt, MAX_GENERATION_ATTEMPTS, reason)
    else:
        log.warning("QC %s urinishdan keyin ham o'tmadi, oxirgi variant baribir ishlatiladi: %s",
                     MAX_GENERATION_ATTEMPTS, last_reason)

    package = {
        "topic": post["topic"],
        "post_html": post["post_html"],
        "plain_text": plain,
        "image_bytes": None,
        "audio_bytes": None,
        "qc_note": last_reason if not passed else "",
    }
    if not text_only:
        try:
            package["image_bytes"] = generate_image(post["image_prompt"])
        except Exception:
            log.exception("Rasm generatsiya qilishda xato, rasmsiz davom etiladi")
    if want_audio:
        try:
            package["audio_bytes"] = generate_audio(post["audio_script"])
        except Exception:
            log.exception("Audio generatsiya qilishda xato, audiosiz davom etiladi")
    return package


async def _send_preview(context: ContextTypes.DEFAULT_TYPE, post_id: str) -> None:
    pkg = PENDING[post_id]["package"]
    caption = f"🕐 Bugungi post ({PUBLISH_HOUR:02d}:{PUBLISH_MINUTE:02d} da chiqadi):\n\n{pkg['post_html']}"
    if pkg["qc_note"]:
        caption += f"\n\n⚠️ QC eslatmasi: {html.escape(pkg['qc_note'])}"

    keyboard = InlineKeyboardMarkup(
        [[InlineKeyboardButton("🔁 Qayta qilish", callback_data=f"regen:{post_id}")]]
    )

    if pkg["image_bytes"] and len(caption) <= 1024:
        msg = await context.bot.send_photo(
            chat_id=ADMIN_CHAT_ID,
            photo=BytesIO(pkg["image_bytes"]),
            caption=caption,
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard,
        )
    else:
        if pkg["image_bytes"]:
            await context.bot.send_photo(chat_id=ADMIN_CHAT_ID, photo=BytesIO(pkg["image_bytes"]))
        msg = await context.bot.send_message(
            chat_id=ADMIN_CHAT_ID,
            text=caption,
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard,
        )
    if pkg["audio_bytes"]:
        await context.bot.send_audio(
            chat_id=ADMIN_CHAT_ID,
            audio=BytesIO(pkg["audio_bytes"]),
            title=pkg["topic"],
            caption="🔊 Shu haftaning audio varianti (kanalga alohida yuboriladi)",
        )
    PENDING[post_id]["preview_message_id"] = msg.message_id


async def _publish_to_channel(context: ContextTypes.DEFAULT_TYPE, post_id: str) -> None:
    pkg = PENDING[post_id]["package"]
    caption = pkg["post_html"]

    if pkg["image_bytes"] and len(caption) <= 1024:
        await context.bot.send_photo(
            chat_id=CHANNEL_ID,
            photo=BytesIO(pkg["image_bytes"]),
            caption=caption,
            parse_mode=ParseMode.HTML,
        )
    else:
        if pkg["image_bytes"]:
            await context.bot.send_photo(chat_id=CHANNEL_ID, photo=BytesIO(pkg["image_bytes"]))
        await context.bot.send_message(chat_id=CHANNEL_ID, text=caption, parse_mode=ParseMode.HTML)

    if pkg["audio_bytes"]:
        await context.bot.send_audio(
            chat_id=CHANNEL_ID, audio=BytesIO(pkg["audio_bytes"]), title=pkg["topic"]
        )

    PENDING[post_id]["status"] = "published"
    state.increment_post_count()
    log.info("Post kanalga chiqarildi: %s", pkg["topic"])


# ---------------------------------------------------------------------------
# Rejalashtirilgan vazifalar
# ---------------------------------------------------------------------------

async def prepare_daily_post(context: ContextTypes.DEFAULT_TYPE) -> None:
    now = datetime.now(TZ)
    next_count = state.get_state().get("post_count", 0) + 1
    text_only = state.should_be_text_only(next_count)
    iso_week = f"{now.isocalendar().year}-W{now.isocalendar().week}"
    want_audio = state.should_send_audio_this_week(iso_week)

    post_id = str(uuid.uuid4())[:8]
    log.info("Kunlik post tayyorlanmoqda (id=%s, text_only=%s, audio=%s)", post_id, text_only, want_audio)

    package = _build_content_package(text_only=text_only, want_audio=want_audio)
    PENDING[post_id] = {"package": package, "status": "pending", "iso_week": iso_week, "want_audio": want_audio}

    await _send_preview(context, post_id)

    # PREVIEW_MINUTES_BEFORE daqiqadan keyin — agar hech kim tugmani
    # bosmagan bo'lsa — avtomatik kanalga chiqarish.
    context.job_queue.run_once(
        publish_if_untouched, when=timedelta(minutes=PREVIEW_MINUTES_BEFORE), data=post_id, name=f"publish:{post_id}"
    )


async def publish_if_untouched(context: ContextTypes.DEFAULT_TYPE) -> None:
    post_id = context.job.data
    entry = PENDING.get(post_id)
    if not entry:
        return
    if entry["status"] == "pending":
        await _publish_to_channel(context, post_id)
        if entry["want_audio"]:
            state.mark_audio_sent(entry["iso_week"])
    # status "regenerating" yoki "published" bo'lsa — bu yerda hech narsa
    # qilinmaydi, chunki regeneratsiya tugagach post darhol chiqariladi.


async def on_regenerate_clicked(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    _, post_id = query.data.split(":", 1)
    entry = PENDING.get(post_id)
    if not entry or entry["status"] != "pending":
        await query.edit_message_reply_markup(reply_markup=None)
        return

    entry["status"] = "regenerating"
    await query.edit_message_caption(
        caption="🔁 Qayta ishlanmoqda, tayyor bo'lishi bilan kanalga chiqariladi...", reply_markup=None
    ) if query.message.caption else await query.edit_message_text(
        "🔁 Qayta ishlanmoqda, tayyor bo'lishi bilan kanalga chiqariladi...", reply_markup=None
    )

    new_package = _build_content_package(text_only=entry["package"]["image_bytes"] is None, want_audio=entry["want_audio"])
    entry["package"] = new_package
    await _publish_to_channel(context, post_id)
    if entry["want_audio"]:
        state.mark_audio_sent(entry["iso_week"])
    await context.bot.send_message(chat_id=ADMIN_CHAT_ID, text="✅ Yangilangan post kanalga chiqarildi.")


async def cmd_myid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/myid — ADMIN_CHAT_ID qiymatini topish uchun yordamchi buyruq."""
    await update.message.reply_text(f"Sizning chat ID'ingiz: {update.effective_chat.id}")


def main() -> None:
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("myid", cmd_myid))
    app.add_handler(CallbackQueryHandler(on_regenerate_clicked, pattern=r"^regen:"))

    publish_time = dt_time(hour=PUBLISH_HOUR, minute=PUBLISH_MINUTE, tzinfo=TZ)
    preview_time = (
        datetime.combine(datetime.today(), publish_time) - timedelta(minutes=PREVIEW_MINUTES_BEFORE)
    ).time().replace(tzinfo=TZ)

    app.job_queue.run_daily(prepare_daily_post, time=preview_time, name="prepare_daily_post")

    log.info(
        "Worker ishga tushdi. Preview: har kuni %s (%s), Nashr: %02d:%02d",
        preview_time, TIMEZONE, PUBLISH_HOUR, PUBLISH_MINUTE,
    )
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
